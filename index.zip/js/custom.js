//<![CDATA[
	$(document).ready(function(){	
		new jPlayerPlaylist({
			jPlayer: "#jquery_jplayer_1",
			cssSelectorAncestor: "#jp_container_1"
		}, [
			{
				title:"Esther, Chapter-1", free:true, mp3:"./media/audio/esther/esther_chapter_1.mp3"			
			},
			{
				title:"Esther, Chapter-2", free:true, mp3:"./media/audio/esther/esther_chapter_2.mp3"			
			},
			{
				title:"Esther, Chapter-3", free:true, mp3:"./media/audio/esther/esther_chapter_3.mp3"			
			},
			{
				title:"Esther, Chapter-4", free:true, mp3:"./media/audio/esther/esther_chapter_4.mp3"			
			},
			{
				title:"Esther, Chapter-5", free:true, mp3:"./media/audio/esther/esther_chapter_5.mp3"			
			},
			{
				title:"Esther, Chapter-6", free:true, mp3:"./media/audio/esther/esther_chapter_6.mp3"			
			},
			{
				title:"Esther, Chapter-7", free:true, mp3:"./media/audio/esther/esther_chapter_7.mp3"			
			},
			{
				title:"Esther, Chapter-8", free:true, mp3:"./media/audio/esther/esther_chapter_8.mp3"			
			},
			{
				title:"Esther, Chapter-9 & 10", free:true, mp3:"./media/audio/esther/esther_chapter_9_10.mp3"			
			}
			
		], {
			swfPath: "../dist/jplayer",
			supplied: "mp3",
			wmode: "window",
			useStateClassSkin: true,
			autoBlur: false,
			smoothPlayBar: true,
			keyEnabled: true			
		});
		
	
		new jPlayerPlaylist({
			jPlayer: "#jquery_jplayer_2",
			cssSelectorAncestor: "#jp_container_2"
		}, [
			{
				title:"Nehemiah, Chapter-5", free:true, mp3:"./media/audio/nehemiah/nehemiah_chapter_5.mp3"			
			},
			{
				title:"Nehemiah, Chapter-6", free:true, mp3:"./media/audio/nehemiah/nehemiah_chapter_6.mp3"			
			},
			{
				title:"Nehemiah, Chapter-7", free:true, mp3:"./media/audio/nehemiah/nehemiah_chapter_7.mp3"			
			},
			{
				title:"Nehemiah, Chapter-8", free:true, mp3:"./media/audio/nehemiah/nehemiah_chapter_8.mp3"			
			}
			
		], {
			swfPath: "../dist/jplayer",
			supplied: "mp3",
			wmode: "window",
			useStateClassSkin: true,
			autoBlur: false,
			smoothPlayBar: true,
			keyEnabled: true
		});
		
		new jPlayerPlaylist({
			jPlayer: "#jquery_jplayer_3",
			cssSelectorAncestor: "#jp_container_3",
		}, [
			{
				title:"Kings-1, Chapter-1", free:true, mp3:"./media/audio/kings_1/kings_1_chapter_1.mp3"			
			},
			{
				title:"Kings-1, Chapter-2", free:true, mp3:"./media/audio/kings_1/kings_1_chapter_2.mp3"			
			},
			{
				title:"Kings-1, Chapter-3", free:true, mp3:"./media/audio/kings_1/kings_1_chapter_3.mp3"			
			},
			{
				title:"Kings-1, Chapter-4", free:true, mp3:"./media/audio/kings_1/kings_1_chapter_4.mp3"			
			},
			{
				title:"Kings-1, Chapter-5", free:true, mp3:"./media/audio/kings_1/kings_1_chapter_5.mp3"			
			},
			{
				title:"Kings-1, Chapter-6", free:true, mp3:"./media/audio/kings_1/kings_1_chapter_6.mp3"			
			},
			{
				title:"Kings-1, Chapter-7", free:true, mp3:"./media/audio/kings_1/kings_1_chapter_7.mp3"			
			},
			{
				title:"Kings-1, Chapter-8", free:true, mp3:"./media/audio/kings_1/kings_1_chapter_8.mp3"			
			},
			{
				title:"Kings-1, Chapter-10", free:true, mp3:"./media/audio/kings_1/kings_1_chapter_10.mp3"			
			},
			{
				title:"Kings-1, Chapter-11", free:true, mp3:"./media/audio/kings_1/kings_1_chapter_11.mp3"			
			},
			{
				title:"Kings-1, Chapter-12", free:true, mp3:"./media/audio/kings_1/kings_1_chapter_12.mp3"			
			},
			{
				title:"Kings-1, Chapter-14", free:true, mp3:"./media/audio/kings_1/kings_1_chapter_14.mp3"			
			},
			{
				title:"Kings-1, Chapter-15", free:true, mp3:"./media/audio/kings_1/kings_1_chapter_15.mp3"			
			},
			{
				title:"Kings-1, Chapter-16", free:true, mp3:"./media/audio/kings_1/kings_1_chapter_16.mp3"			
			},
			{
				title:"Kings-1, Chapter-17, part-1", free:true, mp3:"./media/audio/kings_1/kings_1_chapter_17_part_1.mp3"			
			},
			{
				title:"Kings-1, Chapter-17, part-2", free:true, mp3:"./media/audio/kings_1/kings_1_chapter_17_part_2_7.mp3"			
			},
			{
				title:"Kings-1, Chapter-17, part-3", free:true, mp3:"./media/audio/kings_1/kings_1_chapter_17_part_8_11.mp3"			
			},
			{
				title:"Kings-1, Chapter-18, part-1", free:true, mp3:"./media/audio/kings_1/kings_1_chapter_18_part_1.mp3"			
			},
			{
				title:"Kings-1, Chapter-18, part-2", free:true, mp3:"./media/audio/kings_1/kings_1_chapter_18_part_2.mp3"			
			},
			{
				title:"Kings-1, Chapter-18, part-3", free:true, mp3:"./media/audio/kings_1/kings_1_chapter_18_part_3.mp3"			
			},
			{
				title:"Kings-1, Chapter-18, part-1", free:true, mp3:"./media/audio/kings_1/kings_1_chapter_19_part_1.mp3"			
			},
			{
				title:"Kings-1, Chapter-19, part-2", free:true, mp3:"./media/audio/kings_1/kings_1_chapter_19_part_2.mp3"			
			},
			{
				title:"Kings-1, Chapter-20, part-1", free:true, mp3:"./media/audio/kings_1/kings_1_chapter_20_part_1.mp3"			
			},
			{
				title:"Kings-1, Chapter-20, part-2", free:true, mp3:"./media/audio/kings_1/kings_1_chapter_20_part_2.mp3"			
			},
			{
				title:"Kings-1, Chapter-21", free:true, mp3:"./media/audio/kings_1/kings_1_chapter_21.mp3"			
			},
			{
				title:"Kings-1, Chapter-22, part-1", free:true, mp3:"./media/audio/kings_1/kings_1_chapter_22_part_1.mp3"			
			},
			{
				title:"Kings-1, Chapter-22, part-2", free:true, mp3:"./media/audio/kings_1/kings_1_chapter_22_part_2.mp3"			
			}
			
		],
		  {	
			swfPath: "../dist/jplayer",
			supplied: "mp3",
			wmode: "window",
			useStateClassSkin: true,
			autoBlur: false,
			smoothPlayBar: true,
			keyEnabled: true,
			
						  	  
		});    
	
		new jPlayerPlaylist({
			jPlayer: "#jquery_jplayer_4",
			cssSelectorAncestor: "#jp_container_4",
		}, [
			{
				title:"Kings-2, Chapter-2, part-1", free:true, mp3:"./media/audio/kings_2/kings_2_chapter_1_part_1_3.mp3"			
			},
			{
				title:"Kings-2, Chapter-3, part-1", free:true, mp3:"./media/audio/kings_2/kings_2_chapter_3_part_1_3.mp3"			
			},
			{
				title:"Kings-2, Chapter-4, part-1", free:true, mp3:"./media/audio/kings_2/kings_2_chapter_4_part_1_17.mp3"			
			},
			{
				title:"Kings-2, Chapter-4, part-2", free:true, mp3:"./media/audio/kings_2/kings_2_chapter_4_part_18_44.mp3"			
			},
			{
				title:"Kings-2, Chapter-8, part-1", free:true, mp3:"./media/audio/kings_2/kings_2_chapter_8_part_1_2.mp3"			
			},
			{
				title:"Kings-2, Chapter-8, part-2", free:true, mp3:"./media/audio/kings_2/kings_2_chapter_8_part_7_8.mp3"			
			},
			{
				title:"Kings-2, Chapter-8, part-3", free:true, mp3:"./media/audio/kings_2/kings_2_chapter_8_part_16_17.mp3"			
			},
			{
				title:"Kings-2, Chapter-9, part-1", free:true, mp3:"./media/audio/kings_2/kings_2_chapter_9_part_1_3.mp3"			
			},
			{
				title:"Kings-2, Chapter-10, part-1", free:true, mp3:"./media/audio/kings_2/kings_2_chapter_10_part_1_3.mp3"			
			},
			{
				title:"Kings-2, Chapter-11, part-1", free:true, mp3:"./media/audio/kings_2/kings_2_chapter_11_part_1_3.mp3"			
			},
			{
				title:"Kings-2, Chapter-12, part-1", free:true, mp3:"./media/audio/kings_2/kings_2_chapter_12_part_1_3.mp3"			
			},
			{
				title:"Kings-2, Chapter-13, part-1", free:true, mp3:"./media/audio/kings_2/kings_2_chapter_13_part_1_2.mp3"			
			},
			{
				title:"Kings-2, Chapter-14, part-1", free:true, mp3:"./media/audio/kings_2/kings_2_chapter_14_part_1_3.mp3"			
			},
			{
				title:"Kings-2, Chapter-16", free:true, mp3:"./media/audio/kings_2/kings_2_chapter_16.mp3"			
			},
			{
				title:"Kings-2, Chapter-17", free:true, mp3:"./media/audio/kings_2/kings_2_chapter_17.mp3"			
			},
			{
				title:"Kings-2, Chapter-18, part-1", free:true, mp3:"./media/audio/kings_2/kings_2_chapter_18_part_1_8.mp3"			
			},
			{
				title:"Kings-2, Chapter-21, part-1", free:true, mp3:"./media/audio/kings_2/kings_2_chapter_21_part_1_3.mp3"			
			}
			
		],
		  {	
			swfPath: "../dist/jplayer",
			supplied: "mp3",
			wmode: "window",
			useStateClassSkin: true,
			autoBlur: false,
			smoothPlayBar: true,
			keyEnabled: true,
			
						  	  
		});    
		
		$("#jquery_jplayer_1, #jquery_jplayer_2, #jquery_jplayer_3, #jquery_jplayer_4").bind($.jPlayer.event.loadeddata, function(event) {
			$(".jp-playlist > ul").hide();
		});			
			
		$(".jp-playlist > ul").hide();
			$( ".btn-tog" ).on( "click", function() {
				$(this).closest(".jp-audio").find('.jp-playlist ul').slideToggle();
			});
		
	   
    
		

   
		
	
});
	//]]>
	
	