$('.audio-btn').click(function () {
    var $this = $(this);

    // starting audio
    var audioID = "audio" + $(this).attr('id');
    $("#" + audioID).trigger('stop');

    $this.toggleClass('active');
    if ($this.hasClass('active')) {
        $("#" + audioID).trigger('stop');
        $this.find('span').text('Pause');
        $this.find('i').addClass('fa-pause');
        $this.find('i').removeClass('fa-play');
        $("#" + audioID).trigger('play');
    } else {
        $this.find('span').text('Listen');
        $this.find('i').removeClass('fa-pause');
        $this.find('i').addClass('fa-play');
        $("#" + audioID).trigger('pause');
    }
});



$('.events-blk .btn').hide();
$(".card").mouseenter(function () {
    
    $(this).find('.card-title').stop().stop().animate({ 'padding' : 60, 'margin-bottom' : 30 }, "slow");
           $(this).find('.btn').fadeIn();
    
  }).mouseleave(function () {
    $(this).find('.card-title').animate({ 
      'padding-top' : 15,
      'padding-right' : 0,
      'padding-bottom' : 15,
      'padding-left' : 0,
      'margin-bottom' : 0
    }, "slow");
    $(this).find('.btn').fadeOut();
  });

